# Catatan Penting Penggunaan
<ul>
<li>Salin isi file vendor.zip dan writable.zip ke dalam folder PRAK701 <b>atau</b> langsung gunakan PRAK701.zip.</li>
<li>Praktikum ini menggunakan database sehingga masukkan dulu file database praktikum701.sql ke dalam database sql.</li>
</ul>
